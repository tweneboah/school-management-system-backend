import React, { Component } from 'react'


class Dashboard extends Component {
  render() {
    return (
      <div>
        <h1>Working in backend services...</h1>
      </div>
    )
  }
}


export default Dashboard;