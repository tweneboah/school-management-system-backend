# Documenttion

## Modules

Users [Registration, List, Profile, Edit, Delete]
- [ ] Admin `level-1`
- [ ] Moderator `level-2`
- [ ] Teacher `level-3`
- [ ] Student `level-4`
- [ ] Staff `level-5`

Academic
- [ ] Admission
- [ ] Classes
- [ ] Subjects
- [ ] Grade level
- [ ] Exam
- [ ] Attendence
- [ ] Payment
- [ ] Marksheet
- [ ] Schedule
- [ ] Result
- [ ] Library 
- [ ] Transport
- [ ] News & Event
- [ ] Calender